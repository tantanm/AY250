from setuptools import setup, find_packages
setup(
    name = "CalCalc",
    version = "0.1",
    script= ['CalCalc.py'],
    author = "Sayantan Mukhopadhyay",
    description = "This is an Tiny Package",
    keywords = "Simple application for Wolfram Alpha",
    package_data = {'': ['*.txt', '*.rst']}

)