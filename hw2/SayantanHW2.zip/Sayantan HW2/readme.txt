# Name of Submission: HW1 AY 250 Fall 2013
# Submitted by: Sayantan Mukhopadhyay
# Download Instruction: clone the file SayantanHW1.zip. Then unzip it.
# Installing Instruction: From your bash into the folder HW2. The files setup.py and CalCalc.py files are there. Run the following command "python setup.py.install".
# How to use the file: If you are done with setting up and want to calculate anything or get the answer of any query from wolfram alpha then put your input within quotes and run the folloing command from the bash "python CalCalc.py -s 'X'" where X is your query. e.g. "python CalCalc.py -s '4+2'" will return the value of 4+2 which is 6 in below format: 
"Result for "4+2":
6"
